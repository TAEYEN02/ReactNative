import { View } from "react-native";
import SignupScreen from "./components/SignupScreen";

export default function App (){
    return(
        <View style={{flex:1}}>
            <SignupScreen/>
        </View>
        
    )
}